//
//  ViewController.swift
//  AnimationUdemy-Quoc
//
//  Created by Tiep Nguyen on 2/16/16.
//  Copyright © 2016 Tiep Nguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var counter:Int = 0
    var timer:NSTimer!
    var isStartAnimation = true
   
    @IBOutlet weak var myImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        counter = 1
        timer = NSTimer.scheduledTimerWithTimeInterval(0.0, target: self, selector: Selector("doAnimation"), userInfo: nil, repeats: true)
        
    }
    @IBAction func startStopAnimation(sender: UIButton) {
        if isStartAnimation == false{
            timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: Selector("doAnimation"), userInfo: nil, repeats: true)
            isStartAnimation = true
        }else{
            timer.invalidate()
            isStartAnimation = false
        }
        
    }
    
    func doAnimation() -> Void{
        
        if counter == 8 {
            
            counter = 1
            
        }else{
            
            counter++
            
        }
        
        myImage.image = UIImage(named: "dancing-banana-\(counter) (dragged).tiff")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

