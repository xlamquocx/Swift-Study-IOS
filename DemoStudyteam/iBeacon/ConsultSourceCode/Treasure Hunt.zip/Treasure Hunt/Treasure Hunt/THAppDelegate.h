//
//  THAppDelegate.h
//  Treasure Hunt
//
//  Created by Craig Gilchrist on 20/02/2014.
//  Copyright (c) 2014 Eden Agency Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface THAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
