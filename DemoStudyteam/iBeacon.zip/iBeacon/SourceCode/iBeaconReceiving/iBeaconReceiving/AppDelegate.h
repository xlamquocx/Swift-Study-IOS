//
//  AppDelegate.h
//  iBeaconReceiving
//
//  Created by Tiep Nguyen on 5/25/15.
//  Copyright (c) 2015 Tiep Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

