/*      NSMassFormatter.h
        Copyright (c) 2014, Apple Inc. All rights reserved.
 */

#import <Foundation/NSFormatter.h>

@class NSNumberFormatter;

typedef NS_ENUM(NSInteger, NSMassFormatterUnit) {
    NSMassFormatterUnitGram = 11,
    NSMassFormatterUnitKilogram = 14,
    NSMassFormatterUnitOunce = (6 << 8) + 1,
    NSMassFormatterUnitPound = (6 << 8) + 2,
    NSMassFormatterUnitStone = (6 << 8) + 3,
} NS_ENUM_AVAILABLE(10_10, 8_0);

NS_CLASS_AVAILABLE(10_10, 8_0)
@interface NSMassFormatter : NSFormatter {
@private
    void *_formatter;
    BOOL _isForPersonMassUse;
    void *_reserved[2];
}

@property (copy) NSNumberFormatter *numberFormatter;    // default is NSNumberFormatter with NSNumberFormatterDecimalStyle
@property NSFormattingUnitStyle unitStyle;              // default is NSFormattingUnitStyleMedium
@property (getter = isForPersonMassUse) BOOL forPersonMassUse;  // default is NO; if it is set to YES, the number argument for -stringFromKilograms: and -unitStringFromKilograms: is considered as a person’s mass

// Format a combination of a number and an unit to a localized string.
- (NSString *)stringFromValue:(double)value unit:(NSMassFormatterUnit)unit;

// Format a number in kilograms to a localized string with the locale-appropriate unit and an appropriate scale (e.g. 1.2kg = 2.64lb in the US locale).
- (NSString *)stringFromKilograms:(double)numberInKilograms;

// Return a localized string of the given unit, and if the unit is singular or plural is based on the given number.
- (NSString *)unitStringFromValue:(double)value unit:(NSMassFormatterUnit)unit;

// Return the locale-appropriate unit, the same unit used by -stringFromKilograms:.
- (NSString *)unitStringFromKilograms:(double)numberInKilograms usedUnit:(NSMassFormatterUnit *)unitp;

// No parsing is supported. This method will return NO.
- (BOOL)getObjectValue:(out id *)obj forString:(NSString *)string errorDescription:(out NSString **)error;
@end
